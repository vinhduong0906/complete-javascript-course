"use strict";

//Select element which is multi file use
const inputFirstNameEl = document.getElementById("input-firstname") || null;
const inputLastNameEl = document.getElementById("input-lastname") || null;
const inputUsernameEl = document.getElementById("input-username");
const inputPasswordEl = document.getElementById("input-password");
const inputPasswordConfirmEl =
  document.getElementById("input-password-confirm") || null;
const submidBtnEl = document.getElementById("btn-submit") || null;
const paginationEl = document.querySelector(".pagination") || null;
const newsContainerEl = document.getElementById("news-container") || null;
